import tkinter as tk
from tkinter import messagebox
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os

FILE_NAME = "expenses.csv"

# Create CSV if not exists
if not os.path.exists(FILE_NAME):
    df = pd.DataFrame(columns=["Date", "Category", "Description", "Amount"])
    df.to_csv(FILE_NAME, index=False)

# Function to add expense
def add_expense():
    date = datetime.now().strftime("%Y-%m-%d")
    category = category_entry.get()
    description = description_entry.get()
    amount = amount_entry.get()

    if not category or not description or not amount:
        messagebox.showwarning("Input Error", "Please fill all fields.")
        return

    try:
        amount = float(amount)
    except ValueError:
        messagebox.showerror("Input Error", "Amount must be a number.")
        return

    new_data = pd.DataFrame([[date, category, description, amount]],
                            columns=["Date", "Category", "Description", "Amount"])
    new_data.to_csv(FILE_NAME, mode='a', header=False, index=False)

    messagebox.showinfo("Success", "Expense added successfully!")
    category_entry.delete(0, tk.END)
    description_entry.delete(0, tk.END)
    amount_entry.delete(0, tk.END)

# ✅ Fully working View Expenses function with scrollbar
def view_expenses():
    try:
        df = pd.read_csv(FILE_NAME)

        if df.empty:
            messagebox.showinfo("No Data", "No expenses recorded yet.")
            return

        # Create a new window
        view_window = tk.Toplevel(root)
        view_window.title("Expense Records")
        view_window.geometry("700x400")

        # Scrollbar frame
        frame = tk.Frame(view_window)
        frame.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        text = tk.Text(frame, wrap=tk.NONE, yscrollcommand=scrollbar.set)
        text.insert(tk.END, df.to_string(index=False))
        text.config(state='disabled')  # Read-only
        text.pack(fill=tk.BOTH, expand=True)

        scrollbar.config(command=text.yview)

    except Exception as e:
        messagebox.showerror("Error", f"Could not load expenses:\n{str(e)}")

# Show chart
def show_chart():
    try:
        df = pd.read_csv(FILE_NAME)
        if df.empty:
            messagebox.showinfo("No Data", "No expenses to show.")
            return

        category_totals = df.groupby("Category")["Amount"].sum()
        category_totals.plot(kind='pie', autopct='%1.1f%%', startangle=140)
        plt.title("Spending by Category")
        plt.ylabel("")  # Hide Y label
        plt.tight_layout()
        plt.show()

    except Exception as e:
        messagebox.showerror("Error", str(e))

# Show total summary
def show_summary():
    try:
        df = pd.read_csv(FILE_NAME)
        if df.empty:
            messagebox.showinfo("No Data", "No expenses recorded.")
            return

        total = df["Amount"].sum()
        messagebox.showinfo("Summary", f"Total Spent: ₹{total:.2f}")

    except Exception as e:
        messagebox.showerror("Error", str(e))

# GUI Setup
root = tk.Tk()
root.title("Expense Tracker - Wallet Watch")
root.geometry("400x360")

# Inputs
tk.Label(root, text="Category").grid(row=0, column=0, padx=10, pady=5, sticky='e')
category_entry = tk.Entry(root, width=30)
category_entry.grid(row=0, column=1)

tk.Label(root, text="Description").grid(row=1, column=0, padx=10, pady=5, sticky='e')
description_entry = tk.Entry(root, width=30)
description_entry.grid(row=1, column=1)

tk.Label(root, text="Amount (₹)").grid(row=2, column=0, padx=10, pady=5, sticky='e')
amount_entry = tk.Entry(root, width=30)
amount_entry.grid(row=2, column=1)

# Buttons
tk.Button(root, text="Add Expense", width=25, command=add_expense).grid(row=3, column=0, columnspan=2, pady=10)
tk.Button(root, text="View Expenses", width=25, command=view_expenses).grid(row=4, column=0, columnspan=2, pady=5)
tk.Button(root, text="Show Category Chart", width=25, command=show_chart).grid(row=5, column=0, columnspan=2, pady=5)
tk.Button(root, text="Show Total Summary", width=25, command=show_summary).grid(row=6, column=0, columnspan=2, pady=5)
tk.Button(root, text="View Expenses Again", width=25, command=view_expenses).grid(row=7, column=0, columnspan=2, pady=10)

root.mainloop()